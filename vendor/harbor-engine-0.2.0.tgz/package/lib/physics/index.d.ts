import type { Plugin, Vec3 } from '../core/index.js';
export interface PhysicsOptions {
    /** World units are metres, time is seconds. Y-up characters use the Y component. */
    gravity?: Vec3;
}
export interface PhysicsInspection {
    bodies: number;
    characters: number;
    grounded: Record<string, boolean>;
}
export interface PhysicsService {
    inspect(): PhysicsInspection;
}
/**
 * Optional CPU/WASM physics: works in Node without a browser or GPU.
 *
 * Commands:
 * - physics:move { id, velocity: [vx, 0, vz], jump?: boolean }: persistent horizontal
 *   velocity in metres/second. The Y input is ignored; gravity and jumping own it.
 * - physics:impulse { id, impulse: [x, y, z] }: dynamic bodies only.
 * - physics:teleport { id, position: [x, y, z] }: resets velocity and jump state.
 *
 * Change a body's transform through teleport, not by mutating Entity.position.
 * A body definition is captured at spawn time; remove/re-spawn to replace its shape.
 */
export declare function createRapierPlugin(options?: PhysicsOptions): Promise<Plugin>;
