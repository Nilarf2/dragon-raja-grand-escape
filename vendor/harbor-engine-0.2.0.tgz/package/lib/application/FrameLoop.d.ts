import type { FrameScheduler } from './types.js';
export interface FrameLoopOptions {
    maxDelta?: number;
    scheduler?: FrameScheduler;
    onError?: (error: Error) => void;
}
/** Variable-second application timeline, independent of World's fixed ticks. */
export declare class FrameLoop {
    private readonly options;
    private callbacks;
    private handle;
    private previous;
    private requested;
    private closed;
    private stepping;
    private elapsed;
    private readonly maxDelta;
    private readonly scheduler;
    constructor(options?: FrameLoopOptions);
    get time(): number;
    get running(): boolean;
    add(callback: (dt: number, time: number) => void): () => void;
    step(dt: number): void;
    start(): void;
    private schedule;
    stop(): void;
    dispose(): void;
}
