import type { ApplicationScene, SceneFactory } from './types.js';
export interface SceneManagerOptions {
    onCleanupError?: (error: Error) => void;
}
/** Latest load wins; failed preparation/activation keeps the previous scene alive. */
export declare class SceneManager<Services extends object, State = unknown, Manifest extends {
    id: string;
} = {
    id: string;
}> {
    private readonly services;
    private readonly options;
    private definitions;
    private pending?;
    private generation;
    private closed;
    private active?;
    private operations;
    private commitTail;
    private disposal?;
    private disposedScenes;
    private managedScenes;
    constructor(services: Services, options?: SceneManagerOptions);
    get current(): ApplicationScene<State> | undefined;
    get loading(): boolean;
    get disposed(): boolean;
    register(definition: SceneFactory<Services, State, Manifest>): void;
    list(): Manifest[];
    switchTo(id: string, state?: State): Promise<boolean>;
    private cleanup;
    private load;
    dispose(): Promise<void>;
}
