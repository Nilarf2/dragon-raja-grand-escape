import { FrameLoop } from './FrameLoop.js';
import { SceneManager } from './SceneManager.js';
import type { ApplicationOptions, ApplicationScene } from './types.js';
export { FrameLoop } from './FrameLoop.js';
export type { FrameLoopOptions } from './FrameLoop.js';
export { SceneManager } from './SceneManager.js';
export type { SceneManagerOptions } from './SceneManager.js';
export type * from './types.js';
export interface Application<Services extends object, State = unknown, Manifest extends {
    id: string;
} = {
    id: string;
}> {
    readonly manager: SceneManager<Services, State, Manifest>;
    readonly loop: FrameLoop;
    readonly current: ApplicationScene<State> | undefined;
    readonly running: boolean;
    readonly error: Error | undefined;
    start(): void;
    pause(): void;
    /** One application update with seconds, followed by at most one render. */
    step(seconds: number, render?: boolean): void;
    render(): void;
    resize(width?: number, height?: number): void;
    switchScene(id: string, state?: State): Promise<boolean>;
    snapshot(): State | undefined;
    inspect(): {
        running: boolean;
        loading: boolean;
        time: number;
        scene: Record<string, unknown> | undefined;
    };
    /** Stops immediately; resolves after late candidates, scenes and shared services. */
    dispose(): Promise<void>;
}
/** Native-scene application host. It never replaces the caller's scene/materials/view. */
export declare function createApplication<Services extends object, State = unknown, Manifest extends {
    id: string;
} = {
    id: string;
}>(options: ApplicationOptions<Services, State, Manifest>): Application<Services, State, Manifest>;
