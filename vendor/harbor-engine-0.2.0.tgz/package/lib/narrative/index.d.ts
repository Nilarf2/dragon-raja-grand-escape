export type StoryYield = number | (() => boolean);
export interface StoryBeat {
    id: string;
    run(): Generator<StoryYield, void, unknown>;
}
/** Application-owned story commands; stable checkpoints and generator cleanup. */
export declare class StoryRunner {
    readonly beats: StoryBeat[];
    private changed;
    private completed;
    private iterator?;
    private wait;
    private predicate?;
    private index;
    constructor(beats: StoryBeat[], changed?: () => void, completed?: () => void);
    get active(): boolean;
    get checkpoint(): string | undefined;
    start(id?: string): void;
    private begin;
    next(): void;
    update(dt: number): void;
    stop(): void;
}
