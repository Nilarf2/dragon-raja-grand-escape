import type { Entity, Json, SceneDefinition } from './types.js';
export declare function validateId(input: unknown, path?: string): string;
export declare function validateSeed(input: unknown, path?: string): number;
export declare function validateFixedDelta(input: unknown, path?: string): number;
/** Validate and copy JSON without sharing references or accepting cyclic/non-JSON values. */
export declare function cloneJson(input: unknown, path?: string, parents?: Set<object>, depth?: number): Json;
export declare function validateEntity(input: unknown, path?: string): Entity;
/** A strict, detached scene definition. Validation finishes before a world is created. */
export declare function validateScene(input: unknown): SceneDefinition;
