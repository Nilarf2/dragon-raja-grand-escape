import type { Disposer } from './types.js';
/** Listeners run synchronously in registration order; every listener is attempted. */
export declare class EventBus {
    private listeners;
    private closed;
    on<T>(type: string, listener: (payload: T) => void): Disposer;
    emit(type: string, payload: unknown): void;
    dispose(): void;
}
