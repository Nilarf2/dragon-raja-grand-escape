import type { Disposer } from './types.js';
/** Owns synchronous cleanup. Each registration runs once, in reverse order. */
export declare class Scope {
    private cleanups;
    private closed;
    private controller;
    private unlinkParent?;
    constructor(parentSignal?: AbortSignal);
    get disposed(): boolean;
    get size(): number;
    /** Aborted before cleanup begins, including when a cleanup later throws. */
    get signal(): AbortSignal;
    add(cleanup: Disposer): Disposer;
    /** Alias used by application lifetimes; identical ownership rules to add(). */
    defer(cleanup: Disposer): Disposer;
    listen(target: EventTarget, type: string, listener: EventListenerOrEventListenerObject, options?: AddEventListenerOptions | boolean): Disposer;
    dispose(): void;
}
