import { Scope } from './Scope.js';
import { EventBus } from './events.js';
import type { Command, Disposer, Entity, EntityDefinition, SceneDefinition, WorldSnapshot } from './types.js';
export type SystemPhase = 'beforePhysics' | 'physics' | 'afterPhysics';
export interface System {
    id: string;
    phase?: SystemPhase;
    order?: number;
    update(world: World, dt: number): void;
}
export interface Plugin {
    id: string;
    requires?: string[];
    setup(world: World, scope: Scope): void;
}
export interface WorldOptions {
    seed?: number;
    fixedDelta?: number;
    maxSubSteps?: number;
}
/** Fixed-step simulation. Importing or running this module never requires a browser or GPU. */
export declare class World {
    readonly entities: Map<string, Entity>;
    readonly events: EventBus;
    readonly services: Map<string, unknown>;
    readonly fixedDelta: number;
    readonly maxSubSteps: number;
    private systems;
    private systemOrder?;
    private commands;
    private plugins;
    private installingPlugins;
    private sequence;
    private ticks;
    private remainder;
    private randomState;
    private stepping;
    private closed;
    constructor(options?: WorldOptions);
    get tick(): number;
    get time(): number;
    get disposed(): boolean;
    private assertOpen;
    spawn(definition: EntityDefinition): Entity;
    remove(id: string): boolean;
    get(id: string): Entity | undefined;
    query(tag: string): Entity[];
    addSystem(system: System): Disposer;
    install(plugin: Plugin): void;
    registerCommand(type: string, handler: (command: Command) => unknown): Disposer;
    command(command: Command): unknown;
    step(count?: number): void;
    advance(seconds: number): {
        steps: number;
        alpha: number;
        droppedTime: number;
    };
    random(): number;
    snapshot(): WorldSnapshot;
    dispose(): void;
}
export declare function createWorld(scene: SceneDefinition): World;
