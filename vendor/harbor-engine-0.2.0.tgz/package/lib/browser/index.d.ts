import { type Plugin, type SceneDefinition, type World, type WorldSnapshot } from '../core/index.js';
import type { BrowserRenderer, Quality } from '../render/index.js';
import type { PathTracer, TraceEnvironment } from '../raytrace/types.js';
import type { PathTracingCamera, PathTracingRenderer } from '../pathtracing/index.js';
import type { PerspectiveCamera, Scene } from 'three/webgpu';
export interface GameTraceOptions {
    /** Quality is the full upstream renderer. Compact is the geometry-only reference integrator. */
    backend?: 'quality' | 'compact';
    maxBounces?: number;
    width?: number;
    height?: number;
    /** Advance simulation and synchronize changed geometry; false refines a static view. */
    live?: boolean;
    segments?: number;
    /** Quality backend: caller-owned native scene, including textures, lights and HDR environment. */
    scene?: Scene;
    /** Quality backend: caller-owned native camera. GameOptions.camera optionally sets its pose. */
    camera?: PerspectiveCamera;
    /** Quality backend: wavefront path slots per render dispatch, not samples per pixel. */
    frameBudget?: number;
    /** Quality backend: zero accumulates indefinitely; a settle point can drive an attached denoiser. */
    maxSamples?: number;
    /** Compact backend procedural lighting. Quality lighting belongs to trace.scene. */
    environment?: TraceEnvironment;
}
export interface GameOptions {
    canvas: HTMLCanvasElement;
    scene: SceneDefinition;
    mode?: 'raster' | 'pathtrace';
    /** Defaults to true when the scene declares any physics bodies. */
    physics?: boolean;
    quality?: Quality;
    backend?: 'auto' | 'webgl';
    camera?: PathTracingCamera;
    autoStart?: boolean;
    trace?: GameTraceOptions;
    plugins?: Plugin[];
    onError?: (error: Error) => void;
}
export interface BrowserGame {
    readonly world: World;
    readonly renderer: BrowserRenderer | undefined;
    /** Present only for the explicit compact backend. */
    readonly tracer: PathTracer | undefined;
    /** Quality backend, exposing the native scene, camera and full upstream pathTracer. */
    readonly pathtracing: PathTracingRenderer | undefined;
    readonly running: boolean;
    readonly error: Error | undefined;
    start(): void;
    pause(): void;
    /** Advance exactly count fixed ticks, synchronize the view, and paint once. */
    step(count?: number): void;
    snapshot(): WorldSnapshot;
    setCamera(camera: PathTracingCamera): void;
    /** Rebuild scene/material bindings on the next paint; use step(0) to paint while paused. */
    invalidateScene(): void;
    resize(width?: number, height?: number): void;
    /** Stop synchronously. Await pathtracing?.dispose() afterward when quality GPU teardown must finish. */
    dispose(): void;
}
/** Browser orchestration with optional modules loaded only for the requested game. */
export declare function createGame(options: GameOptions): Promise<BrowserGame>;
