export interface CompleteFramePlan {
    columns: number;
    rows: number;
    dispatches: number;
    tileWidth: number;
    tileHeight: number;
    maxTilePixels: number;
    /** Upstream divides image pixels by this hint before choosing its grid. */
    backendBudget: number;
}
/** Match the pinned megakernel grid, correcting edge rounding without reducing resolution. */
export declare function completeFramePlan(width: number, height: number, budget: number): CompleteFramePlan;
