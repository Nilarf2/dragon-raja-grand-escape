import { PerspectiveCamera, Scene, WebGPURenderer } from 'three/webgpu';
import { WebGPUPathTracer, type SampleCounts } from 'three-gpu-pathtracer/webgpu';
import type { World } from '../core/index.js';
import { type WorldSceneBridge } from './from-world.js';
export { createWorldSceneBridge } from './from-world.js';
export type { WorldSceneBridge, WorldSceneChange } from './from-world.js';
export { PhysicalCamera } from 'three-gpu-pathtracer';
export { WebGPUPathTracer, OIDNDenoiser, FSRUpscaler } from 'three-gpu-pathtracer/webgpu';
export { createQualityDevice, createPathTracingView } from './native-view.js';
export type { PathTracingView, PathTracingViewOptions, PathTracingViewInspection } from './native-view.js';
export { compactTraceGeometry, PreparedQualityScene, assertTraceMaterial } from './prepare-scene.js';
export type { GeometryCompaction, QualitySceneChange, PreparedSceneInspection } from './prepare-scene.js';
export { StaticRefinementController } from './static-refinement.js';
export type { StaticDenoiser, StaticDenoiseFrame, RefinementState, RefinementInspection } from './static-refinement.js';
export { createOIDNStaticDenoiser, verifyOIDNWeights, OIDN_LARGE_WEIGHTS } from './oidn-static.js';
export type { OIDNStaticOptions, OIDNStaticDenoiser } from './oidn-static.js';
export { createPathTracingOutputNode } from './output.js';
export interface PathTracingCamera {
    position: [number, number, number];
    target: [number, number, number];
    up?: [number, number, number];
    fov?: number;
    /** World units. Requires PhysicalCamera; the default camera is physical. */
    focusDistance?: number;
    /** Positive f-stop, or Infinity for a pinhole camera. */
    fStop?: number;
}
export interface PathTracingOptions {
    canvas: HTMLCanvasElement;
    /** Full Three scene: standard/physical materials, textures, lights and HDR environment. Caller-owned. */
    scene?: Scene;
    camera?: PerspectiveCamera;
    world?: World;
    width?: number;
    height?: number;
    maxBounces?: number;
    /** Upstream wavefront path slots per render call; higher is faster convergence, longer frames. */
    frameBudget?: number;
    /** Zero accumulates indefinitely. A nonzero settle point enables an attached OIDN denoiser. */
    maxSamples?: number;
    segments?: number;
    onError?: (error: Error) => void;
}
export interface PathTracingInspection {
    backend: 'webgpu';
    implementation: 'three-gpu-pathtracer';
    width: number;
    height: number;
    maxBounces: number;
    frameBudget: number;
    maxSamples: number;
    meshes: number;
    triangles: number;
    texturePages: number;
    textureWidth: number;
    textureHeight: number;
    samples: SampleCounts | null;
    limits: {
        maxBufferSize: number;
        maxStorageBufferBindingSize: number;
        maxTextureDimension2D: number;
    };
    error?: string;
}
export interface PathTracingRenderer {
    readonly renderer: WebGPURenderer;
    readonly scene: Scene;
    readonly camera: PerspectiveCamera;
    /** The complete upstream API, including material/environment/light updates, OIDN and FSR. */
    readonly pathTracer: WebGPUPathTracer;
    readonly worldBridge?: WorldSceneBridge;
    render(): void;
    resize(width: number, height: number): void;
    setCamera(camera: PathTracingCamera): void;
    /** Returns true only when the world changed; unchanged snapshots keep accumulating. */
    syncWorld(): boolean;
    /** Rebuild after scene graph or geometry edits; this can block on large CPU BVH builds. */
    invalidateScene(): void;
    reset(): void;
    inspect(): PathTracingInspection;
    /** Explicit GPU readback; inspect() itself does not stall to measure samples. */
    measureSamples(): Promise<SampleCounts>;
    /** Stops immediately; await to finish owned GPU-device cleanup. Safe to call repeatedly. */
    dispose(): Promise<void>;
}
/** Native WebGPU path tracing using the mature upstream wavefront implementation. No WebGL fallback. */
export declare function createPathTracingRenderer(options: PathTracingOptions): Promise<PathTracingRenderer>;
