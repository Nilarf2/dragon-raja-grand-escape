import type { PerspectiveCamera, Scene, Texture } from 'three/webgpu';
import type { SampleCounts } from 'three-gpu-pathtracer/webgpu';
import type { PathTracingView } from './native-view.js';
export interface StaticDenoiseFrame {
    color: Texture;
    scene: Scene;
    camera: PerspectiveCamera;
    signal: AbortSignal;
}
export interface StaticDenoiser {
    denoise(frame: StaticDenoiseFrame): Promise<Texture>;
    reset(): void;
    dispose(): void | Promise<void>;
}
export type RefinementState = 'idle' | 'sampling' | 'denoising' | 'complete' | 'error';
export interface RefinementInspection {
    state: RefinementState;
    targetSamples: 64 | 256;
    samples: SampleCounts | null;
    revision: number;
    denoised: boolean;
    error?: string;
}
/**
 * Static-image lifecycle only. The application freezes its whole simulation while
 * active and calls tick after rendering. No polling loop blocks input or the RAF.
 */
export declare class StaticRefinementController {
    readonly view: PathTracingView;
    readonly denoiser: StaticDenoiser;
    private onError?;
    private state;
    private target;
    private capturedRevision;
    private generation;
    private active;
    private disposed;
    private measuring;
    private counts;
    private result;
    private aborter;
    private error;
    private previousMaxSamples;
    private task;
    constructor(view: PathTracingView, denoiser: StaticDenoiser, onError?: ((error: Error) => void) | undefined);
    get outputTexture(): Texture;
    start(options?: {
        samples?: 64 | 256;
    }): void;
    private cancelTask;
    private capture;
    cancel(): void;
    tick(): void;
    private beginDenoise;
    private fail;
    inspect(): RefinementInspection;
    dispose(): Promise<void>;
}
