import { Group, Mesh, type Scene } from 'three/webgpu';
import type { World } from '../core/index.js';
export type WorldSceneChange = 'none' | 'transforms' | 'scene';
export interface WorldSceneBridge {
    readonly group: Group;
    getObject(id: string): Mesh | undefined;
    /** Synchronize definitions and transforms; unchanged worlds preserve accumulated samples. */
    sync(): WorldSceneChange;
    dispose(): void;
}
/** Owns only the generated group, geometries and standard physical materials. */
export declare function createWorldSceneBridge(world: World, scene: Scene, options?: {
    segments?: number;
}): WorldSceneBridge;
