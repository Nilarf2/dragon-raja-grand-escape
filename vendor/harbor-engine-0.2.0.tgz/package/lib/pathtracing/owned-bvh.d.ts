import { type BufferAttribute, type Camera, type Scene, type WebGPURenderer } from 'three/webgpu';
import type { WebGPUPathTracer } from 'three-gpu-pathtracer/webgpu';
interface PackedData {
    storage: Record<string, {
        value?: BufferAttribute;
    }>;
    textureAtlas: {
        setTextures(renderer: WebGPURenderer, textures: unknown[]): void;
        dispose(): void;
    };
    textures: unknown[];
    fns?: {
        getCameraRay?: unknown;
    };
    materials?: unknown[];
    bvh?: unknown;
    bvhMap?: Map<unknown, unknown>;
    materialsMap?: Map<unknown, unknown>;
    _bvhCache?: Map<unknown, unknown>;
    objects?: unknown[];
    dispose(): void;
    update(): void;
}
/**
 * Compatibility boundary for three 0.186.1 and the locked native tracer revision.
 * Compute-only storage attributes do not have Three's geometry disposal listener.
 * Upstream also allocates a new CPU pack before retiring the old one. Keep this
 * workaround scoped to the tracer's own pack, never the borrowed scene/device.
 */
export declare class OwnedPathTracingBVH {
    private renderer;
    private createData;
    private released;
    private releasedAttributes;
    constructor(renderer: WebGPURenderer, createData?: (scene: Scene) => PackedData);
    release(data?: PackedData): void;
    private releaseAttribute;
    updateLights(tracer: WebGPUPathTracer): void;
    disposeTracer(tracer: WebGPUPathTracer): void;
    setScene(tracer: WebGPUPathTracer, scene: Scene, camera: Camera): void;
}
export {};
