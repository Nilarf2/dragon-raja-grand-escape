import { type PerspectiveCamera, type Scene, type WebGPURenderer } from 'three/webgpu';
import { type UNet } from 'oidn-web';
import type { StaticDenoiser } from './static-refinement.js';
export declare const OIDN_LARGE_WEIGHTS: Readonly<{
    file: "rt_hdr_calb_cnrm_large.08130cdc4f33b7a5.tza";
    originalFile: "rt_hdr_calb_cnrm_large.tza";
    bytes: 7698439;
    sha256: "08130cdc4f33b7a513d0073757f089ac830f900613bb5bad72ca42c52b934465";
    commit: "28883d1769d5930e13cf7f1676dd852bd81ed9e7";
    license: "Apache-2.0";
}>;
export interface OIDNStaticOptions {
    renderer: WebGPURenderer;
    scene?: Scene;
    camera?: PerspectiveCamera;
    /** A same-origin build asset. No implicit CDN, model service, or network backend. */
    weightsUrl: string | URL;
    /** Bounded FP32 tiles; the full image is retained at the requested resolution. */
    maxTileSize?: number;
}
export interface OIDNStaticDenoiser extends StaticDenoiser {
    inspect(): {
        state: 'idle' | 'loading' | 'running' | 'complete' | 'error';
        precision: 'fp32';
        model: string;
        error?: string;
        runtime?: ReturnType<UNet['getRuntimeInfo']>;
    };
}
export declare function verifyOIDNWeights(bytes: ArrayBuffer): Promise<void>;
/** Clean-guided local OIDN, sharing the native renderer's device and always using FP32. */
export declare function createOIDNStaticDenoiser(options: OIDNStaticOptions): OIDNStaticDenoiser;
