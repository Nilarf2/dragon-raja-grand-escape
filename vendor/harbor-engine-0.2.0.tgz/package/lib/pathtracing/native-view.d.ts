import { PerspectiveCamera, type Scene, type Texture, type WebGPURenderer } from 'three/webgpu';
import { WebGPUPathTracer, type SampleCounts } from 'three-gpu-pathtracer/webgpu';
import { type PreparedSceneInspection, type QualitySceneChange } from './prepare-scene.js';
export interface PathTracingViewOptions {
    /** Initialized native WebGPU renderer; its canvas, device and output policy remain caller-owned. */
    renderer: WebGPURenderer;
    scene: Scene;
    camera: PerspectiveCamera;
    width?: number;
    height?: number;
    maxBounces?: number;
    frameBudget?: number;
    maxSamples?: number;
    /** Complete full-resolution sample per render (default), or one progressive tile. */
    samplingMode?: 'complete-frame' | 'progressive';
    onError?: (error: Error) => void;
}
export interface PathTracingViewInspection extends PreparedSceneInspection {
    backend: 'webgpu';
    implementation: 'three-gpu-pathtracer';
    width: number;
    height: number;
    revision: number;
    maxBounces: number;
    maxSamples: number;
    frameBudget: number;
    samplingMode: 'complete-frame' | 'progressive';
    tracingKernel: 'megakernel';
    tiles: {
        columns: number;
        rows: number;
        dispatches: number;
        maxTilePixels: number;
    };
    samples: SampleCounts | null;
    texturePages: number;
    textureWidth: number;
    textureHeight: number;
    /** Actual single packed vertex binding; excludes all other renderer resources. */
    packedAttributeBytes?: number;
    limits: {
        maxBufferSize: number;
        maxStorageBufferBindingSize: number;
        maxTextureDimension2D: number;
    };
    error?: string;
}
export interface PathTracingView {
    readonly renderer: WebGPURenderer;
    /** Caller-owned source scene. */
    readonly scene: Scene;
    /** Read-only private PBR graph, also used for matching denoising guides. */
    readonly preparedScene: Scene;
    readonly camera: PerspectiveCamera;
    readonly pathTracer: WebGPUPathTracer;
    readonly revision: number;
    /** Linear HDR, top-to-bottom image. Output tone mapping belongs to the application. */
    readonly outputTexture: Texture;
    /** Accumulates one complete sample by default; never presents or changes output policy. */
    render(): void;
    /** Dimensions are drawing-buffer pixels. Does not resize the renderer or change the camera. */
    resize(width: number, height: number): void;
    syncScene(change: QualitySceneChange): boolean;
    reset(): void;
    measureSamples(): Promise<SampleCounts>;
    inspect(): PathTracingViewInspection;
    dispose(): Promise<void>;
}
/** Request actual adapter limits for large native scenes; no optional FP16 requirement. Caller owns the result. */
export declare function createQualityDevice(): Promise<GPUDevice>;
/**
 * Native quality view borrowing an application's renderer. Its private compact graph
 * prevents upstream BVH preparation from changing application geometry or skeletons.
 */
export declare function createPathTracingView(options: PathTracingViewOptions): Promise<PathTracingView>;
