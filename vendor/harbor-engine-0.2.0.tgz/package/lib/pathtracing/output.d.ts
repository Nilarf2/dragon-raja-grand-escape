import type { Texture } from 'three/webgpu';
/** Linear HDR source for one final RenderPipeline. Update textureNode.value after denoising. */
export declare function createPathTracingOutputNode(initialTexture: Texture): {
    textureNode: import("three/webgpu").TextureNode<"vec4">;
    colorNode: import("three/webgpu").Node;
};
