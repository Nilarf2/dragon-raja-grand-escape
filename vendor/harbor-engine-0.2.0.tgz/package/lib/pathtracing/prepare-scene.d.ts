import { BufferGeometry, Object3D, Scene, type Material } from 'three/webgpu';
export interface GeometryCompaction {
    readonly geometry: BufferGeometry;
    readonly sourceVertices: number;
    readonly vertices: number;
    readonly triangles: number;
    readonly bytes: number;
    /** New vertex index -> original vertex index. Also used for deformation refreshes. */
    readonly sourceIndices: Uint32Array;
}
/**
 * Losslessly copy only referenced vertices. Never clones the full height-field first,
 * mutates the source index/BVH, flattens instances, or merges different material groups.
 */
export declare function compactTraceGeometry(source: BufferGeometry, useGroups?: boolean): GeometryCompaction;
export interface QualitySceneChange {
    camera?: boolean;
    transforms?: boolean;
    materials?: boolean;
    lights?: boolean;
    environment?: boolean;
    /** Refit/rebuild the named objects' private geometry, including skin/morph deformation. */
    geometry?: readonly Object3D[];
    topology?: boolean;
}
export interface PreparedSceneInspection {
    meshes: number;
    instances: number;
    uniqueGeometries: number;
    sourceMeshes: number;
    sourceInstances: number;
    maxGeometryGroups: number;
    sourceVertices: number;
    compactVertices: number;
    triangles: number;
    expandedTriangles: number;
    geometryBytes: number;
    /** Estimated single packed vertex binding, excluding BVH, ray state, textures and denoising. */
    estimatedAttributeBytes: number;
}
/** Strict admission: application-specific TSL must be converted or explicitly composited. */
export declare function assertTraceMaterial(material: Material, object: Object3D): void;
/** Owns private graph/BVH/geometry; source materials and textures remain borrowed. */
export declare class PreparedQualityScene {
    readonly source: Scene;
    scene: Scene;
    private mapping;
    private cache;
    private parts;
    private disposed;
    constructor(source: Scene);
    private releaseGraph;
    rebuild(): void;
    syncTransforms(): void;
    syncEnvironment(): void;
    syncMaterials(): void;
    /** Re-copy named source geometries only, retaining untouched private BVHs. */
    updateGeometry(objects: readonly Object3D[]): void;
    inspect(): PreparedSceneInspection;
    dispose(): void;
}
