export interface SaveStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
}
export interface SaveStoreOptions<T> {
    /** Exact storage key. No namespace or envelope is added. */
    key: string;
    /** Validate and preferably detach the application-owned save schema. */
    validate(value: unknown): T;
    /** Omit for page-local memory. Access to window.localStorage must itself be guarded. */
    storage?: SaveStorage;
}
/** Raw application saves, with a truthful storage-denied/quota fallback. */
export declare class SaveStore<T> {
    private text;
    private storage;
    private readonly key;
    private readonly validate;
    constructor(options: SaveStoreOptions<T>);
    get persistent(): boolean;
    write(value: T): void;
    read(): T | undefined;
}
