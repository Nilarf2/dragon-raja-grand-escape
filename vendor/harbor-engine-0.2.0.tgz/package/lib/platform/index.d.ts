export interface PlatformAdapter {
    readonly id: string;
    ready(): void;
    save(key: string, value: unknown): boolean;
    load<T>(key: string, validate: (value: unknown) => value is T): T | undefined;
    dispose(): void;
}
/** Standalone/iframe baseline. Host SDKs implement this interface in the game. */
export declare function createBrowserPlatform(namespace: string, storage?: Pick<Storage, 'getItem' | 'setItem'>): PlatformAdapter;
export { SaveStore } from './SaveStore.js';
export type { SaveStorage, SaveStoreOptions } from './SaveStore.js';
