import { AssetManager } from './AssetManager.js';
export { AssetManager } from './AssetManager.js';
export type { AssetHandle, AssetLoader } from './AssetManager.js';
export { Actor } from './Actor.js';
export { disposeObject } from './disposeObject.js';
/** Self-contained GLB avoids uncancellable external dependencies and CDN requests. */
export declare function assertEmbeddedGLB(buffer: ArrayBuffer): void;
export declare function createAssetManager(): AssetManager;
