import { AnimationMixer, type Object3D, type AnimationClip } from 'three/webgpu';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { AssetHandle } from './AssetManager.js';
export declare class Actor {
    readonly id: string;
    private release;
    readonly root: Object3D;
    readonly mixer: AnimationMixer;
    private actions;
    private current?;
    private disposed;
    private listeners;
    constructor(id: string, template: {
        scene: Object3D;
        animations: AnimationClip[];
    }, release?: () => void);
    static fromHandle(id: string, handle: AssetHandle<GLTF>): Actor;
    get clips(): string[];
    play(name: string, fade?: number, once?: boolean): void;
    onFinished(callback: (name: string) => void): () => void;
    update(dt: number): void;
    dispose(): void;
}
