export interface AssetLoader<T> {
    load(url: string, signal: AbortSignal): Promise<T>;
    dispose(value: T): void;
}
export interface AssetHandle<T> {
    value: T;
    release(): void;
}
/** Shared in-flight requests, explicit ownership, and safe disposal of late completions. */
export declare class AssetManager {
    private entries;
    private loaders;
    private closed;
    register<T>(type: string, loader: AssetLoader<T>): void;
    get size(): number;
    acquire<T>(type: string, url: string, signal?: AbortSignal): Promise<AssetHandle<T>>;
    dispose(): void;
}
