import type { Object3D } from 'three/webgpu';
/** Use for an owned asset template; cloned instances share its geometry/materials. */
export declare function disposeObject(root: Object3D | Iterable<Object3D>): void;
