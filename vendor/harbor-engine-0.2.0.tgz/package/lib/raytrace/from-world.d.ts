import type { World } from '../core/index.js';
import type { TraceScene } from './types.js';
/**
 * Snapshot declarative world visuals as real triangles and linear PBR constants.
 * TSL ocean/sky, external Three objects, textures, skinning and custom shaders are not extracted.
 */
export interface WorldTraceOptions {
    segments?: number;
}
export declare function fromWorld(world: World, { segments }?: WorldTraceOptions): TraceScene;
