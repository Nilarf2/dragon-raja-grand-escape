import { type Object3D } from 'three';
import type { TraceScene } from './types.js';
export interface FromThreeOptions {
    /** Explicitly permit approximations/skipped unsupported objects instead of throwing. */
    allowUnsupported?: boolean;
    /** Receives every distinct permitted approximation; defaults to console.warn. */
    onWarning?: (message: string) => void;
}
/**
 * Snapshot visible Three meshes into detached world-space triangles and linear PBR constants.
 * No DOM/GPU is needed. Cameras, lights, fog and environment are configured separately.
 *
 * Supports indexed/interleaved geometry, material groups, draw ranges, ordinary meshes,
 * instances and instance colors. Negative scales preserve outward winding. Static GLTF
 * meshes can be passed directly. Live skinning/morphs must first be baked to plain meshes.
 * Texture maps, custom shader nodes and unsupported physical lobes fail explicitly.
 * With allowUnsupported, such materials use their constant PBR factors; animated geometry
 * and unsupported renderable object kinds are skipped with warnings. Input assets are never
 * disposed or rewritten. Call again after changing transforms/instances/materials.
 */
export declare function fromThreeScene(root: Object3D, options?: FromThreeOptions): TraceScene;
