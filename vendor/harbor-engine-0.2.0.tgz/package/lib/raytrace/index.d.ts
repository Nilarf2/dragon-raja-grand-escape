import type { PathTracer, PathTracerOptions } from './types.js';
export { buildBVH, refitBVH } from './bvh.js';
export { fromWorld } from './from-world.js';
export { fromThreeScene } from './from-three.js';
export type { FromThreeOptions } from './from-three.js';
export type { WorldTraceOptions } from './from-world.js';
export type * from './types.js';
/**
 * Independent WebGPU compute path tracer. Initialization requires a WebGPU adapter;
 * callers choose their own raster fallback when one is unavailable.
 */
export declare function createPathTracer(options: PathTracerOptions): Promise<PathTracer>;
