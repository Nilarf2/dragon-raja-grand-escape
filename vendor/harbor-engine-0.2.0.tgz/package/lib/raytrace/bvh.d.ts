import type { BuiltBVH, TraceTriangle, TraceVec3 } from './types.js';
export declare function finiteVec3(value: unknown, label: string): asserts value is TraceVec3;
/** Deterministic median-split, triangle BVH; pure CPU and usable without a DOM or GPU. */
export declare function buildBVH(triangles: readonly TraceTriangle[], leafSize?: number): BuiltBVH;
/** In-place CPU refit: preserves topology, allocations, and original triangle order. */
export declare function refitBVH(bvh: BuiltBVH, triangles: readonly TraceTriangle[]): BuiltBVH;
