import { Object3D, PerspectiveCamera, Scene, WebGPURenderer } from 'three/webgpu';
import { type World } from '../core/index.js';
export { createOcean } from './ocean.js';
export type { Ocean, OceanOptions } from './ocean.js';
export type Quality = 'low' | 'medium' | 'high';
export interface BrowserRendererOptions {
    canvas: HTMLCanvasElement;
    world: World;
    backend?: 'auto' | 'webgl';
    quality?: Quality;
    /** Width of one static batch cell in world units; smaller cells improve culling. */
    batchCellSize?: number;
    /** Defaults are renderer-owned; callers may replace scene background/environment. */
    sky?: boolean;
    fog?: boolean;
    bloom?: boolean;
}
export interface RenderStats {
    backend: 'webgpu' | 'webgl2';
    quality: Quality;
    drawCalls: number;
    triangles: number;
    geometries: number;
    textures: number;
    instances: number;
    batches: number;
    objects: number;
    cachedGeometries: number;
    cachedMaterials: number;
    pixelRatio: number;
    bloom: boolean;
}
export interface BrowserRenderer {
    renderer: WebGPURenderer;
    scene: Scene;
    camera: PerspectiveCamera;
    /** Paint once. Simulation advancement remains the application's responsibility. */
    render(dt?: number): void;
    resize(width: number, height: number): void;
    setQuality(quality: Quality): void;
    /** Rebuild shared visuals after editing shape/material/static transforms in place. */
    invalidateScene(): void;
    inspect(): RenderStats;
    /** Static batched entities return their shared InstancedMesh. */
    getObject(id: string): Object3D | undefined;
    /** Resolve an ordinary object, or an InstancedMesh raycast's instanceId. */
    getEntityId(object: Object3D, instanceId?: number): string | undefined;
    dispose(): void;
}
/**
 * The only engine module that requires a browser/GPU context.
 * Three's WebGPURenderer selects WebGPU, with the same TSL graph on WebGL2 fallback.
 */
export declare function createBrowserRenderer(options: BrowserRendererOptions): Promise<BrowserRenderer>;
