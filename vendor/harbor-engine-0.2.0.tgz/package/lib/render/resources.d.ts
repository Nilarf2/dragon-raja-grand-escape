import { MeshStandardNodeMaterial, type BufferGeometry } from 'three/webgpu';
import type { Visual } from '../core/types.js';
/** Renderer-owned caches. Materials and geometries are shared, never entity-owned. */
export declare class VisualResources {
    readonly geometries: Map<string, BufferGeometry<import("three").NormalBufferAttributes, import("three").BufferGeometryEventMap>>;
    readonly materials: Map<string, MeshStandardNodeMaterial>;
    private usedGeometry;
    private usedMaterial;
    begin(): void;
    acquire(visual: Visual): {
        geometry: BufferGeometry;
        material: MeshStandardNodeMaterial;
        key: string;
    };
    /** Retain resources still used after a world rebuild; release the rest immediately. */
    sweep(): void;
    dispose(): void;
}
