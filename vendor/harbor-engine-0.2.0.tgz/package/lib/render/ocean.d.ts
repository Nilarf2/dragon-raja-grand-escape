import { Mesh, MeshStandardNodeMaterial, PlaneGeometry } from 'three/webgpu';
export interface OceanOptions {
    size?: number;
    level?: number;
}
export interface Ocean {
    object: Mesh<PlaneGeometry, MeshStandardNodeMaterial>;
    /** Simulation seconds; driven explicitly by the caller, with no hidden clock. */
    update(time: number): void;
    dispose(): void;
}
/** Small analytic TSL ocean; no GPU compute or external textures are required. */
export declare function createOcean({ size, level }?: OceanOptions): Ocean;
