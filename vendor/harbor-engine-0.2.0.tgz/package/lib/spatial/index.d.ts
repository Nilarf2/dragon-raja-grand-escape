export interface Rect {
    x: number;
    z: number;
    hw: number;
    hd: number;
    c: number;
    s: number;
}
/** CPU broad phase. Exact oriented collision and walkable-height rules belong to the game. */
export declare class SpatialIndex<T extends Rect> {
    readonly cellSize: number;
    private cells;
    private keys;
    constructor(cellSize?: number);
    private range;
    add(rect: T): () => void;
    remove(rect: T): void;
    query(x: number, z: number, radius?: number): Set<T>;
    clear(): void;
    get size(): number;
}
